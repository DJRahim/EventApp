from bs4 import BeautifulSoup
from lxml import html
import requests
import pymysql
import time


#find_element_by_id
#find_elements_by_name
#find_elements_by_xpath
#find_elements_by_link_text
#find_elements_by_partial_link_text
#find_elements_by_tag_name
#find_elements_by_class_name
#find_elements_by_css_selector

base_connection= pymysql.connect(
    host = 'localhost',
    user = 'joke',
    password = '1234',
    db ='api_admin'
    )
t=set()
for y in range(1,51):
	url="https://www.eventbrite.com/d/online/all-events/?page="+str(y)
	data=requests.get(url).text
	soup=BeautifulSoup(data,'lxml')
	l=soup.find_all("article")
	print(y)
	print("\n")
	for x in l:
		t.add(x.aside.a.get('href'))
		
	
print(len(t))
for x in range(len(t)):
	y=t.pop()
	id_evenement=y
	data=requests.get(y).text
	soup=BeautifulSoup(data,'lxml')
	nom=soup.find("h1").text
	#description1=soup.find_all("p")
	description=soup.find("div",'structured-content-rich-text structured-content__module l-align-left l-mar-vert-6 l-sm-mar-vert-4 text-body-medium')
	#for z in description1:
	#	description=description+str(z.text)
	try:
		image=soup.find("picture").get('content')
	except Exception as e:
		image='none'
	try:
		date2=soup.find("time",'clrfix').text
	except Exception as e:
		date2=soup.find("time")
	#date3=str(date2.text)
	##for y in date2:
		#date3=date3+str(y.text)
	sub_title=soup.find("h2").text		
	cursor =base_connection.cursor()
	sql="INSERT INTO evenement_eventbrite (id_evenement,nom,description,image,date3,sub_title) VALUES (%s ,%s , %s, %s , %s,%s)"
	cursor.execute(sql,(str(id_evenement),str(nom),str(description),str(image),str(date2),str(sub_title)))
	base_connection.commit()			
