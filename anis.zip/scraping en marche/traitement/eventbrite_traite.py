import time
from lxml import html
import requests
import pymysql
import datetime
from bs4 import BeautifulSoup


base_connection= pymysql.connect(
    host = 'localhost',
    user = 'joke',
    password = '1234',
    db ='api_admin'
    )
cursor =base_connection.cursor()
sql="SELECT * FROM evenement_eventbrite"
cursor.execute(sql)
res=cursor.fetchall()
for x in range(len(res)):
	debut=res[x][4]
	debut=str(debut)
	debut=debut.splitlines()
	print(debut)
	print('\n')
	try:
	
		date=debut[1]
		date_debut = datetime.datetime.strptime(date,"%a, %b %d, %Y, %H:%M %p –")
		date=debut[2]
		date=date.replace(debut[2].split(' ')[-1],"")
		date_fin = datetime.datetime.strptime(date,"%a, %b %d, %Y, %H:%M %p ")
		time_zone=debut[2].split(' ')[-1]
	except Exception as e:
		try:
		
			date=debut[1]+' '+debut[2].split('–')[0]
			date_debut = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M ")
			time_zone=debut[2].split(' ')[-1]
			date=debut[1]+' '+debut[2].split(' ')[-2]
			date_fin = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M")
		except Exception as e:
		
			try:
				date=debut[1]+' '+debut[2].split('–')[0]
				date_debut = datetime.datetime.strptime(date,"%a, %B %d, %Y %H:%M %p ")
				date=debut[1]+' '+debut[2].split(' ')[-3]
				date_fin = datetime.datetime.strptime(date,"%a, %B %d, %Y %H:%M")
				time_zone=debut[2].split(' ')[-1]
			except Exception as e:
				try:
					date=debut[1]+' '+debut[2].split('–')[0]
					date_debut = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M %p ")
					date=debut[1]+' '+debut[2].split(' ')[-3]
					date_fin = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M")
					time_zone=debut[2].split(' ')[-1]
				except Exception as e:
					try:
						date=debut[1]+' '+debut[2].split('–')[0]
						date_debut = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M %p ")
						date=debut[1]+' '+debut[2].split(' ')[3]
						date_fin = datetime.datetime.strptime(date,"%a, %d %B %Y %H:%M")
						time_zone=debut[2].split(' ')[4]
					except Exception as e:
						try:
							date=debut[1]+' '+debut[2].split('–')[0]
							date_debut = datetime.datetime.strptime(date,"%a., %d %B %Y %H:%M %p ")
							time_zone=debut[2].split(' ')[-1]
							date=debut[1]+' '+debut[2].split(' ')[-3]
							date_fin = datetime.datetime.strptime(date,"%a., %d %B %Y %H:%M")
						except Exception as e:
							date_debut ="1-1-1 00:00:00"
							date_fin = "1-1-1 00:00:00"
							time_zone = None
#date=date.replace("–", fin)
#date=date.replace(" ", "-")


	
	description=debut=res[x][2]
	try:
		soup = BeautifulSoup(description)

		description =soup.get_text()
	except Exception as e:
		description = None
	cursor =base_connection.cursor()
	sql="INSERT INTO eventbrite_traiter (nom,date_debut,date_fin,limk_image,description,contact,time_zone) VALUES (%s ,%s , %s, %s , %s,%s,%s)"
	cursor.execute(sql,(str(res[x][1]),str(date_debut),str(date_fin),str(res[x][3]),str(description),str(res[x][0]),str(time_zone)))
	base_connection.commit()
	
#print(convert_datetime_timezone("CST"))
#PDT("in" print pytz.common_timezones_set)
