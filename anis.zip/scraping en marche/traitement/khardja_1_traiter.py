import time
from lxml import html
import requests
import pymysql
import datetime
import dateparser
from bs4 import BeautifulSoup



base_connection= pymysql.connect(
    host = 'localhost',
    user = 'joke',
    password = '1234',
    db ='api_admin'
    )
cursor =base_connection.cursor()
sql="SELECT * FROM evenement_khardja_1"
cursor.execute(sql)
res=cursor.fetchall()
for x in range(len(res)):
	debut=res[x][8]
	try:
		date=debut.split(' ')
		date_debut=date[2]+' '+date[3]+' '+date[4]+' '+date[5]
		
		date_debut=dateparser.parse(date_debut , date_formats=['%Y-%B-%d %H:%M'])
		
		date_fin=date[8]+' '+date[9]+' '+date[10]+' '+date[11]
		date_fin=dateparser.parse(date_fin, date_formats=['%Y-%B-%d %H:%M'])
		
		
	except Exception as e:
		date_debut='1-1-1 00:00'
		date_fin='1-1-1 00:00'
	print("\n--------------------")
	
	
	d=res[x][2]
	d=d.strip("\n")
	d=d.replace('\"','')
	d=d.replace('\', \'','')
	d=d.replace('[\'','')
	d=d.replace('\'','')
	d=d.replace(']','')
	d=d.replace('.,','. ')
	d=d.rstrip()
	
	#d=" ".join()
	#d=d.split('\',')
	#description=str(d)
	
	cursor =base_connection.cursor()
	sql="INSERT INTO khardja_1_traiter (nom,date_debut,date_fin,limk_image,description,contact,telephone,lieu,address,categorie,facebook)  VALUES (%s ,%s , %s, %s , %s,%s,%s, %s, %s , %s,%s)"
	cursor.execute(sql,(res[x][10],str(date_debut),str(date_fin),res[x][8],d,res[x][7],res[x][11],res[x][9],res[x][0],res[x][1],res[x][5]))
	base_connection.commit()
