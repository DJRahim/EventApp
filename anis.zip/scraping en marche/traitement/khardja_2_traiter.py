import time
from lxml import html
import requests
import pymysql
import datetime
import dateparser
from bs4 import BeautifulSoup


base_connection= pymysql.connect(
    host = 'localhost',
    user = 'joke',
    password = '1234',
    db ='api_admin'
    )
cursor =base_connection.cursor()
sql="SELECT * FROM evenement_khardja_2"
cursor.execute(sql)
res=cursor.fetchall()
for x in range(len(res)):
	
	print("\n--------------------")
	
	
	d=res[x][2]
	d=d.strip("\n")
	d=d.replace('\"','')
	d=d.replace('\', \'','')
	d=d.replace('[\'','')
	d=d.replace('\'','')
	d=d.replace(']','')
	d=d.replace('.,','. ')
	d=d.rstrip()
	
	#d=" ".join()
	#d=d.split('\',')
	#description=str(d)
	
	cursor =base_connection.cursor()
	sql="INSERT INTO khardja_2_traiter (nom,limk_image,description,contact,telephone,address,categorie,facebook)  VALUES (%s  , %s,%s,%s, %s, %s , %s,%s)"
	cursor.execute(sql,(res[x][7],res[x][6],d,res[x][4],res[x][8],res[x][0],res[x][1],res[x][3]))
	base_connection.commit()
