import time
from lxml import html
import requests
import pymysql
from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
#find_element_by_id
#find_elements_by_name
#find_elements_by_xpath
#find_elements_by_link_text
#find_elements_by_partial_link_text
#find_elements_by_tag_name
#find_elements_by_class_name
#find_elements_by_css_selector

base_connection= pymysql.connect(
    host = 'localhost',
    user = 'joke',
    password = '1234',
    db ='api_admin'
    )
from selenium import webdriver
data= webdriver.Firefox()
data.get("https://www.kherdja.com/index.php?option=com_etabs&view=etabs&Itemid=240&id=")
#p=data.find_elements_by_class_name('post-readmore')

#t=[elem.get_attribute('href') for elem in p]
#print (len(t))
#s=t[0]
#print(s)
j=data.find_element_by_xpath('/html/body/main/div/div[2]/div/section/h1/span')
num = j.text
print(num)
number=int(num)
i=0
while i<=number:
	WebDriverWait(data, 1000000).until(EC.element_to_be_clickable((By.XPATH, '/html/body/main/div/div[2]/div/section/p/button'))).click()
	i=i+1
	number=number - 15
p1=data.find_elements_by_class_name('post-readmore')

t1=[elem.get_attribute('href') for elem in p1]
number=len(t1)
print(number)

for x in range(number):
	
	
	data.quit()
	data= webdriver.Firefox()
	try:
		data.get(t1[x])
	except Exception as e:
		data.get(t1[x])
	
	categorie=data.find_element_by_class_name('article-category').text
	
	nom =data.find_element_by_class_name("article-title").text
	
	description1 = data.find_element_by_class_name('article-description')
	descriptions=description1.find_elements_by_tag_name('p')
	description=[elem.text for elem in descriptions]
	
	
	try:
		
		image =WebDriverWait(data, 5).until(EC.presence_of_element_located((By.CLASS_NAME, "article-thumbnails-preview"))).get_attribute('src')
		
	except Exception as e:
		image =WebDriverWait(data, 5).until(EC.presence_of_element_located((By.CLASS_NAME, "article-thumbnails_preview"))).get_attribute('src')
		
	WebDriverWait(data, 30)
	if categorie !="Plein air/events" and categorie != "Théâtre"and categorie != "Randonnées" and categorie !="Concert" and categorie !="Cinéma" and categorie !="Ateliers" and categorie != "Actus" and categorie != "Arts et culture/events" and categorie != "Divertissement" and categorie != "Expo" :
		address=data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[1]').text
		
		telphone =data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[2]/a')
		print(telphone.get_attribute('href'))
		
		try:
			facebook=data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[4]/strong').text
			
		except Exception as e:
			raise e
		cursor =base_connection.cursor()
		sql="INSERT INTO evenement_khardja_2 (categorie,nom,descriptions,image,address,telphone,facebook,id_evenement_2) VALUES (%s ,%s , %s, %s ,%s , %s, %s, %s)"
		cursor.execute(sql,(str(categorie),str(nom),str(description),str(image),str(address),str(telphone.get_attribute('href')),str(facebook),str(t1[x])))
		base_connection.commit()
		
	else:
		if categorie != "Actus" :
			try:
				Lieu=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[1]').text
			
			except Exception as e:
				Lieu='null'
			try:
				address=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[2]').text
				telphone=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[3]/a')
			except Exception as e:
				address=data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[1]').text				
			
				telphone =data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[2]/a')
			
			try:	
				date_debut_fin=data.find_elements_by_class_name("article-date")
				date_debut = date_debut_fin[0].text
			except Exception as e:
				date_debut_fin="no"
				date_debut = "no"
			
			try:
				facebook=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[5]/strong').text
				
			except Exception as e:
				facebook=data.find_element_by_xpath('/html/body/main/div[3]/div[1]/article/div/section[2]/div/div[1]/ul/li[4]/strong').text
			cursor =base_connection.cursor()
			sql="INSERT INTO evenement_khardja_1 (categorie,nom,descriptions,image,Lieu,address,telphone,date_debut_fin,date_debut,facebook,id_evenement) VALUES (%s ,%s , %s, %s,%s ,%s , %s, %s,%s ,%s , %s)"
			cursor.execute(sql,(str(categorie),str(nom),str(description),str(image),str(Lieu),str(address),str(telphone.get_attribute('href')),str(date_debut_fin),str(date_debut),str(facebook),str(t1[x])))
			base_connection.commit()
			
		else:
			ecrit_part=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[1]').text
			date_debut_fin=data.find_element_by_xpath('/html/body/main/div[2]/div[1]/article/div/section[2]/div/div[1]/ul/li[3]').text
			
			cursor =base_connection.cursor()
			sql="INSERT INTO evenement_khardja_3 (categorie,nom,descriptions,image,ecrit_part,date_debut_fin,id_evenement_3) VALUES (%s , %s, %s,%s , %s,%s,%s)"
			cursor.execute(sql,(str(categorie),str(nom),str(description),str(image),str(ecrit_part),str(date_debut_fin),str(t1[x])))
			base_connection.commit()
			
	
